import os
import cv2
import numpy as np
import mediapipe as mp
from flask import Flask, render_template, request, Response, url_for, redirect
from werkzeug.utils import secure_filename
from tensorflow.keras.models import load_model

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 1. Load the Model 
# Note: If this fails with a 'groups' error, your .h5 file requires the patch you had before.
MODEL_PATH = './face_mask_detector_mobile-net-v2_model.keras'
model = load_model(MODEL_PATH, compile=False)

# 2. Setup Mediapipe
mp_face_detection = mp.solutions.face_detection
face_detector = mp_face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5)

def process_frame(frame):
    h, w, _ = frame.shape
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_detector.process(rgb_frame)

    if results.detections:
        for detection in results.detections:
            bbox = detection.location_data.relative_bounding_box
            x, y, bw, bh = int(bbox.xmin * w), int(bbox.ymin * h), int(bbox.width * w), int(bbox.height * h)
            
            # Boundary clipping
            x, y = max(0, x), max(0, y)
            
            # Extract and Preprocess Face
            face = frame[y:y+bh, x:x+bw]
            if face.size == 0: continue
            
            face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
            face = cv2.resize(face, (224, 224))
            face = np.expand_dims(face, axis=0) # Model expects (1, 224, 224, 3)

            # Prediction logic
            prediction = model.predict(face, verbose=0)[0][0]
            label = "No Mask" if prediction >= 0.7 else "Mask"
            color = (0, 0, 255) if label == "No Mask" else (0, 255, 0)
            conf = prediction if label == "No Mask" else 1 - prediction

            # Draw results
            display_text = f"{label}: {conf*100:.1f}%"
            cv2.rectangle(frame, (x, y), (x+bw, y+bh), color, 2)
            cv2.putText(frame, display_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
    return frame

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    def generate():
        cap = cv2.VideoCapture(0)
        while True:
            success, frame = cap.read()
            if not success: break
            frame = process_frame(frame)
            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
        cap.release()
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files.get('file')
    if file and file.filename != '':
        filename = secure_filename(file.filename)
        path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(path)
        
        image = cv2.imread(path)
        processed = process_frame(image)
        cv2.imwrite(path, processed)
        
        return render_template('index.html', uploaded_image=url_for('static', filename=f'uploads/{filename}'))
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)